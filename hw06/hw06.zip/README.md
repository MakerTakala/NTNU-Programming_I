# Homework06 41047025 王重鈞

## 6.1 Point Mirroring
---
It is a library named mirror, you can use set_line function to set a function, using get_mirror functino to find the mirror point with the line you set by set_line function. If set_line argument is wrong, the program will use the last correct setting.

## 6.2 Extended Euclidean Algorithm
---
It is a library named ext, you can use ext_euclidean function to find multiplicative inverse of b mod a. If a < b, return -1 and c is meaningless. If gcd(a, b) != 1, return 0 and c is the gcd. If gcd(a, b) == 1, return 1, and gcd is multiplicative inverse of b mod a.

## 6.3 Integer Editor
---
This is a Integer Editor, which can allow you to edit an number.

## 6.4 Finite State Machine
---
Same description with hw0303.

## 6.5 Dynamic Memory Allocation
This is a realloc implementation.
