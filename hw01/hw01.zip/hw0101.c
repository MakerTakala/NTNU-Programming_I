#include <stdio.h>

int main(){
    printf("THE LAST BUG\n\
\n\
\"But you're out of your mind ,\"\n\
They said with a shrug.\n\
\"The customer's happy;\n\
What's one little bug?\"\n\
\n\
But he was determined.\n\
The others went home.\n\
He spread out the program ,\n\
Deserted , alone.\n\
\n\
The cleaning men came,\n\
The whole room was cluttered\n\
With memory -dumps , punch cards.\n\
\"I'm close ,\" he muttered.\n\
\n\
The mumbling got louder ,\n\
Simple deduction ,\n\
\"I've got it, it's right ,\n\
Just change one instruction.\"\n\
\n\
It still wasn't perfect ,\n\
As year followed year ,\n\
And strangers would comment ,\n\
\"Is that guy still here?\"\n\
\n\
He died at the console ,\n\
Of hunger and thirst.\n\
Next day he was buried ,\n\
Face down , nine -edge first.\n\
\n\
And the last bug in sight ,\n\
An ant passing by,\n\
36 Saluted his tombstone ,\n\
And whispered , \"Nice try.\n\
");
    return 0;
}