#include <stdio.h>
#include <stdint.h>
#include "banqi.h"

int main(){
    banqi_game();
    return 0;
}