#pragma once

#include <stdint.h>

int32_t big_two_sort( int8_t [] );
int compare(const void * , const void * );