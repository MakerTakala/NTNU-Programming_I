#ifndef MIDFUNCTION_H_INCLUDE
#define MIDFUNCTION_H_INCLUDE

#include <stdint.h>

void errorMessageExit(char []);
void askInput(char [], int64_t* );


#endif