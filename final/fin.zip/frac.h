#pragma once

#include <stdint.h>

int32_t frac_add( int32_t *, int32_t *, int32_t , int32_t , int32_t , int32_t  );
int32_t frac_del( int32_t *, int32_t *, int32_t , int32_t , int32_t , int32_t  );
int32_t frac_mul( int32_t *, int32_t *, int32_t , int32_t , int32_t , int32_t  );
int32_t frac_div( int32_t *, int32_t *, int32_t , int32_t , int32_t , int32_t  );