#pragma once

#include <stdint.h>

int32_t max_black_chain( int32_t [][19]);